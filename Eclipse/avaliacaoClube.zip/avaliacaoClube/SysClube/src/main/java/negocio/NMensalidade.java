package negocio;

import persistencia.PMensalidade;

public class NMensalidade {

	PMensalidade dao;

	
	public NMensalidade(PMensalidade dao) {
		this.dao = dao;
	}
	
	
	
}
