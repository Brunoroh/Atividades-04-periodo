package persistencia;
import entidade.EAssociado;

public class PAssociado {

	public EAssociado consultar(int codigo){
		return null;
	}

	public EAssociado consultarPorUsuario(String usuario) {
		return null;
	}
	
}
