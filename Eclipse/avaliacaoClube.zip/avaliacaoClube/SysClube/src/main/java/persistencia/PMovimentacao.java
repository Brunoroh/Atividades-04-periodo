package persistencia;

import entidade.EMovimentacao;

public class PMovimentacao {

	public boolean incluir(EMovimentacao entidade) {
		return true;
	}
	
	
	public EMovimentacao consultar(int codigo){
		return null;
	}


	public boolean alterar(EMovimentacao entidade) {
		return true;
	}

}
