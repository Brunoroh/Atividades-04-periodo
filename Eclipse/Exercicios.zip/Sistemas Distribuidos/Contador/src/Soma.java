

public class Soma {
	private double valor = 0.0;
	private boolean finishedRead;

	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public boolean isFinishedRead() {
		return finishedRead;
	}
	public void setFinishedRead(boolean finishedRead) {
		this.finishedRead = finishedRead;
	}
	
	
}
