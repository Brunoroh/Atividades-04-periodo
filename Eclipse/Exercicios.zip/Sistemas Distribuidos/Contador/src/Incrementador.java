
public class Incrementador extends Thread {
	
	public Incrementador(){
		
	}

}
