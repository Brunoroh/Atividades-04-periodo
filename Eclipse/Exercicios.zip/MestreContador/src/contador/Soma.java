package contador;

public class Soma {
	private int valor;
	private boolean finishedRead;
		
	public Soma() {
		valor = 0;
	}
	public int getValor() {
		return valor;
	}
	public void setValor(int valor) {
		this.valor = valor;
	}
	public boolean isFinishedRead() {
		return finishedRead;
	}
	public void setFinishedRead(boolean finishedRead) {
		this.finishedRead = finishedRead;
	}
	
	
}
