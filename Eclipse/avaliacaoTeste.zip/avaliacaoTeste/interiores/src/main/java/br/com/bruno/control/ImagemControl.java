package br.com.bruno.control;

import br.com.bruno.bll.ImagemBs;

public class ImagemControl {

	ImagemBs bs;

	public ImagemControl(ImagemBs bs) {
		this.bs = bs;
	}

	public ImagemControl() {
	}
	
	
	
}
